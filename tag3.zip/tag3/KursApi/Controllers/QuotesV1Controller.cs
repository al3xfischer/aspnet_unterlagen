using Asp.Versioning;
using KursApi.Models;
using KursApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/quotes")]
public class QuotesV1Controller : ControllerBase
{
    private readonly IQuoteService _service;
    public QuotesV1Controller(IQuoteService service) => _service = service;

    [HttpGet]
    public async Task<IActionResult> GetAll()
        => Ok((await _service.GetAllAsync()).Select(q => new { q.Id, q.Text }));

    [HttpGet("{id:int}")]
    public async Task<IActionResult> GetById(int id)
    {
        var quote = await _service.GetAsync(id);
        if (quote is null) return NotFound();
        return Ok(new { quote.Id, quote.Text });
    }

    [HttpPost]
    public async Task<IActionResult> Create(Quote quote)
    {
        var created = await _service.AddAsync(quote);
        if (created is null) return Conflict("Maximale Anzahl Zitate erreicht.");
        return CreatedAtAction(nameof(GetById),
            new { id = created.Id, version = "1.0" },
            new { created.Id, created.Text });
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
        => await _service.DeleteAsync(id) ? NoContent() : NotFound();
}
