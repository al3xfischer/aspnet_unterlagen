using Asp.Versioning;
using KursApi.Models;
using KursApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[ApiVersion("2.0")]
[Route("api/v{version:apiVersion}/quotes")]
public class QuotesV2Controller : ControllerBase
{
    private readonly IQuoteService _service;
    public QuotesV2Controller(IQuoteService service) => _service = service;

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Quote>>> GetAll()
        => Ok(await _service.GetAllAsync());

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Quote>> GetById(int id)
    {
        var quote = await _service.GetAsync(id);
        if (quote is null) return NotFound();
        return quote;
    }

    [HttpPost]
    public async Task<ActionResult<Quote>> Create(Quote quote)
    {
        var created = await _service.AddAsync(quote);
        if (created is null) return Conflict("Maximale Anzahl Zitate erreicht.");
        return CreatedAtAction(nameof(GetById),
            new { id = created.Id, version = "2.0" }, created);
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
        => await _service.DeleteAsync(id) ? NoContent() : NotFound();
}
