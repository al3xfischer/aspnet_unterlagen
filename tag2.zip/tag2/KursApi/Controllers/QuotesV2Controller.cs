using Asp.Versioning;
using KursApi.Models;
using KursApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[ApiVersion("2.0")]
[Route("api/v{version:apiVersion}/quotes")]
public class QuotesV2Controller : ControllerBase
{
    private readonly IQuoteService _service;
    public QuotesV2Controller(IQuoteService service) => _service = service;

    [HttpGet]
    public ActionResult<IEnumerable<Quote>> GetAll() => Ok(_service.GetAll());

    [HttpGet("{id:int}")]
    public ActionResult<Quote> GetById(int id)
    {
        var quote = _service.Get(id);
        if (quote is null) return NotFound();
        return quote;
    }

    [HttpPost]
    public ActionResult<Quote> Create(Quote quote)
    {
        var created = _service.Add(quote);
        if (created is null) return Conflict("Maximale Anzahl Zitate erreicht.");
        return CreatedAtAction(nameof(GetById),
            new { id = created.Id, version = "2.0" }, created);
    }

    [HttpDelete("{id:int}")]
    public IActionResult Delete(int id) => _service.Delete(id) ? NoContent() : NotFound();
}
