using KursApi.Models;

namespace KursApi.Services;

public interface IQuoteService
{
    IEnumerable<Quote> GetAll();
    Quote? Get(int id);
    Quote? Add(Quote quote);
    bool Delete(int id);
}
