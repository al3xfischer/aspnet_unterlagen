using KursApi.Configuration;
using KursApi.Models;
using Microsoft.Extensions.Options;

namespace KursApi.Services;

public class QuoteService : IQuoteService
{
    private readonly List<Quote> _quotes = new();
    private readonly QuoteOptions _options;

    public QuoteService(IOptions<QuoteOptions> options) => _options = options.Value;

    public IEnumerable<Quote> GetAll() => _quotes;

    public Quote? Get(int id) => _quotes.FirstOrDefault(q => q.Id == id);

    public Quote? Add(Quote quote)
    {
        if (_quotes.Count >= _options.MaxQuotes) return null;
        quote.Id = _quotes.Count == 0 ? 1 : _quotes.Max(q => q.Id) + 1;
        _quotes.Add(quote);
        return quote;
    }

    public bool Delete(int id) => _quotes.RemoveAll(q => q.Id == id) > 0;
}
