using Asp.Versioning;
using KursApi.Configuration;
using KursApi.Services;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers()
    .AddXmlSerializerFormatters()
    .AddJsonOptions(o => o.JsonSerializerOptions.WriteIndented = true);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new() { Title = "KursApi", Version = "v1" });
    o.SwaggerDoc("v2", new() { Title = "KursApi", Version = "v2" });
    var xml = Path.Combine(AppContext.BaseDirectory, "KursApi.xml");
    o.IncludeXmlComments(xml);
});

builder.Services.AddApiVersioning(o =>
{
    o.DefaultApiVersion = new ApiVersion(1, 0);
    o.AssumeDefaultVersionWhenUnspecified = true;
    o.ReportApiVersions = true;
})
.AddMvc()
.AddApiExplorer(o =>
{
    o.GroupNameFormat = "'v'VVV";
    o.SubstituteApiVersionInUrl = true;
});

builder.Services.Configure<GreetingOptions>(builder.Configuration.GetSection("Greeting"));
builder.Services.Configure<QuoteOptions>(builder.Configuration.GetSection("Quotes"));

builder.Services.AddTransient<IGreetingService, GreetingService>();
builder.Services.AddSingleton<IQuoteService, QuoteService>();

var app = builder.Build();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(o =>
    {
        o.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
        o.SwaggerEndpoint("/swagger/v2/swagger.json", "v2");
    });
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();

app.Run();
