using KursApi.Services;

namespace KursApi.Tests;

public class GreetingServiceTests
{
    [Fact]
    public void Greet_ContainsName()
    {
        var service = new GreetingService();

        var result = service.Greet("Anna");

        Assert.Equal("Hallo Anna", result);
    }

    [Fact]
    public void TwoInstances_HaveDifferentIds()
    {
        Assert.NotEqual(new GreetingService().InstanceId, new GreetingService().InstanceId);
    }

    [Theory]
    [InlineData("Anna")]
    [InlineData("Ben")]
    public void Greet_StartsWithHallo(string name)
    {
        Assert.StartsWith("Hallo", new GreetingService().Greet(name));
    }
}
