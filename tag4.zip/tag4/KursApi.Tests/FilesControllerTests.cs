using System.Text;
using KursApi.Controllers;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.FileProviders;

namespace KursApi.Tests;

public class FilesControllerTests : IDisposable
{
    private readonly string _root = Directory.CreateTempSubdirectory().FullName;

    public void Dispose() => Directory.Delete(_root, recursive: true);

    [Fact]
    public async Task UploadRaw_StoresFile_WithServerGeneratedName()
    {
        var result = await Upload("image/png");

        Assert.IsType<OkObjectResult>(result);
        var file = Assert.Single(Directory.GetFiles(Path.Combine(_root, "uploads")));
        Assert.Equal(".png", Path.GetExtension(file));
        Assert.True(Guid.TryParse(Path.GetFileNameWithoutExtension(file), out _));
    }

    [Fact]
    public async Task UploadRaw_Returns415_ForUnknownType()
    {
        var result = await Upload("application/x-msdownload");

        Assert.Equal(415, Assert.IsType<StatusCodeResult>(result).StatusCode);
        Assert.False(Directory.Exists(Path.Combine(_root, "uploads")));
    }

    private Task<IActionResult> Upload(string contentType)
    {
        var http = new DefaultHttpContext();
        http.Request.ContentType = contentType;
        http.Request.Body = new MemoryStream(Encoding.UTF8.GetBytes("Hallo"));
        var controller = new FilesController(new TestEnvironment { ContentRootPath = _root })
        {
            ControllerContext = new ControllerContext { HttpContext = http }
        };
        return controller.UploadRaw(CancellationToken.None);
    }

    private class TestEnvironment : IWebHostEnvironment
    {
        public string WebRootPath { get; set; } = "";
        public IFileProvider WebRootFileProvider { get; set; } = new NullFileProvider();
        public string ApplicationName { get; set; } = "";
        public IFileProvider ContentRootFileProvider { get; set; } = new NullFileProvider();
        public string ContentRootPath { get; set; } = "";
        public string EnvironmentName { get; set; } = "";
    }
}
