using KursApi.Configuration;
using KursApi.Data;
using KursApi.Models;
using KursApi.Services;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging.Abstractions;
using Microsoft.Extensions.Options;

namespace KursApi.Tests;

public class QuoteServiceTests
{
    [Fact]
    public async Task AddAsync_ReturnsNull_WhenMaximumReached()
    {
        var dbOptions = new DbContextOptionsBuilder<LibraryContext>()
            .UseInMemoryDatabase(Guid.NewGuid().ToString())
            .Options;
        using var db = new LibraryContext(dbOptions);
        var service = new QuoteService(db,
            Options.Create(new QuoteOptions { MaxQuotes = 1 }),
            NullLogger<QuoteService>.Instance);

        Assert.NotNull(await service.AddAsync(new Quote { Text = "Eins" }));
        Assert.Null(await service.AddAsync(new Quote { Text = "Zwei" }));
    }
}
