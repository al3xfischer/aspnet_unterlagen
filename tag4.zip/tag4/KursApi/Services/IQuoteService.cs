using KursApi.Models;

namespace KursApi.Services;

public interface IQuoteService
{
    Task<List<Quote>> GetAllAsync();
    Task<Quote?> GetAsync(int id);
    Task<Quote?> AddAsync(Quote quote);
    Task<bool> DeleteAsync(int id);
}
