using KursApi.Configuration;
using KursApi.Data;
using KursApi.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;

namespace KursApi.Services;

public class QuoteService : IQuoteService
{
    private readonly LibraryContext _db;
    private readonly QuoteOptions _options;
    private readonly ILogger<QuoteService> _logger;

    public QuoteService(LibraryContext db, IOptions<QuoteOptions> options, ILogger<QuoteService> logger)
    {
        _db = db;
        _options = options.Value;
        _logger = logger;
    }

    public Task<List<Quote>> GetAllAsync() => _db.Quotes.ToListAsync();

    public async Task<Quote?> GetAsync(int id) => await _db.Quotes.FindAsync(id);

    public async Task<Quote?> AddAsync(Quote quote)
    {
        if (await _db.Quotes.CountAsync() >= _options.MaxQuotes)
        {
            _logger.LogWarning("Maximum von {Max} Zitaten erreicht", _options.MaxQuotes);
            return null;
        }
        quote.Id = 0;
        _db.Quotes.Add(quote);
        await _db.SaveChangesAsync();
        _logger.LogInformation("Zitat {QuoteId} angelegt", quote.Id);
        return quote;
    }

    public async Task<bool> DeleteAsync(int id)
    {
        var quote = await _db.Quotes.FindAsync(id);
        if (quote is null) return false;
        _db.Quotes.Remove(quote);
        await _db.SaveChangesAsync();
        _logger.LogInformation("Zitat {QuoteId} gelöscht", id);
        return true;
    }
}
