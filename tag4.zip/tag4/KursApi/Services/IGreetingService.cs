namespace KursApi.Services;

public interface IGreetingService
{
    Guid InstanceId { get; }
    string Greet(string name);
}
