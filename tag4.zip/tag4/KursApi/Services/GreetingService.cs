namespace KursApi.Services;

public class GreetingService : IGreetingService
{
    public Guid InstanceId { get; } = Guid.NewGuid();

    public string Greet(string name) => $"Hallo {name}";
}
