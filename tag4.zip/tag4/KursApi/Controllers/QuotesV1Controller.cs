using Asp.Versioning;
using KursApi.Models;
using KursApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;

namespace KursApi.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/quotes")]
[Authorize]
public class QuotesV1Controller : ControllerBase
{
    private readonly IQuoteService _service;
    private readonly IOutputCacheStore _cache;

    public QuotesV1Controller(IQuoteService service, IOutputCacheStore cache)
    {
        _service = service;
        _cache = cache;
    }

    [HttpGet, AllowAnonymous]
    public async Task<IActionResult> GetAll()
        => Ok((await _service.GetAllAsync()).Select(q => new { q.Id, q.Text }));

    [HttpGet("{id:int}"), AllowAnonymous]
    public async Task<IActionResult> GetById(int id)
    {
        var quote = await _service.GetAsync(id);
        if (quote is null) return NotFound();
        return Ok(new { quote.Id, quote.Text });
    }

    [HttpPost]
    public async Task<IActionResult> Create(Quote quote, CancellationToken ct)
    {
        var created = await _service.AddAsync(quote);
        if (created is null) return Conflict("Maximale Anzahl Zitate erreicht.");
        await _cache.EvictByTagAsync("quotes", ct);
        return CreatedAtAction(nameof(GetById),
            new { id = created.Id, version = "1.0" },
            new { created.Id, created.Text });
    }

    [HttpDelete("{id:int}"), Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        if (!await _service.DeleteAsync(id)) return NotFound();
        await _cache.EvictByTagAsync("quotes", ct);
        return NoContent();
    }
}
