using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[ApiVersion("2.0")]
[Route("api/v{version:apiVersion}/greeting")]
public class GreetingV2Controller : ControllerBase
{
    [HttpGet]
    public object Get() => new { Text = "Hallo aus Version 2", Zeit = DateTime.Now };
}
