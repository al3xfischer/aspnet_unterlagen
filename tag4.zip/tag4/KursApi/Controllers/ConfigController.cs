using KursApi.Configuration;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Options;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ConfigController : ControllerBase
{
    private readonly GreetingOptions _options;

    public ConfigController(IOptions<GreetingOptions> options)
        => _options = options.Value;

    [HttpGet]
    public string Get()
        => string.Join(" ", Enumerable.Repeat(_options.Text, _options.Repeat));
}
