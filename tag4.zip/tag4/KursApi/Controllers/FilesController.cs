using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
[RequestSizeLimit(5 * 1024 * 1024)]
public class FilesController : ControllerBase
{
    private static readonly Dictionary<string, string> AllowedTypes = new(StringComparer.OrdinalIgnoreCase)
    {
        ["text/plain"] = ".txt",
        ["image/png"] = ".png",
        ["image/jpeg"] = ".jpg",
        ["application/pdf"] = ".pdf"
    };

    private readonly string _folder;

    public FilesController(IWebHostEnvironment env)
        => _folder = Path.Combine(env.ContentRootPath, "uploads");

    [HttpPost("multipart")]
    public async Task<IActionResult> UploadMultipart(IFormFile file, CancellationToken ct)
    {
        await using var source = file.OpenReadStream();
        return await SaveAsync(source, file.ContentType, ct);
    }

    [HttpPost("raw")]
    public Task<IActionResult> UploadRaw(CancellationToken ct)
        => SaveAsync(Request.Body, Request.ContentType, ct);

    private async Task<IActionResult> SaveAsync(Stream source, string? contentType, CancellationToken ct)
    {
        var mediaType = contentType?.Split(';')[0].Trim();
        if (mediaType is null || !AllowedTypes.TryGetValue(mediaType, out var extension))
            return StatusCode(StatusCodes.Status415UnsupportedMediaType);

        Directory.CreateDirectory(_folder);
        var fileName = $"{Guid.NewGuid()}{extension}";
        var path = Path.Combine(_folder, fileName);

        try
        {
            await using var target = System.IO.File.Create(path);
            await source.CopyToAsync(target, ct);
            return Ok(new { fileName, size = target.Length });
        }
        catch (Exception ex)
        {
            System.IO.File.Delete(path);
            if (ex is BadHttpRequestException bad) return StatusCode(bad.StatusCode);
            throw;
        }
    }
}
