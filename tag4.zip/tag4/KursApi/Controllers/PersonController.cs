using KursApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class PersonController : ControllerBase
{
    [HttpGet]
    public Person Get() => new Person { Name = "Anna", Age = 34 };

    [HttpPost]
    public IActionResult Create(PersonDto dto) => Ok(dto);
}
