using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.RateLimiting;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize]
public class SecureController : ControllerBase
{
    [HttpGet, AllowAnonymous, EnableRateLimiting("fixed")]
    public string Get() => "Für alle sichtbar";

    [HttpGet("me")]
    public object Me() => new
    {
        Name = User.Identity?.Name,
        IstAdmin = User.IsInRole("Admin")
    };

    [HttpPost]
    public string Post() => "Nur für angemeldete Benutzer";

    [HttpDelete, Authorize(Policy = "AdminOnly")]
    public string Delete() => "Nur für Admins";
}
