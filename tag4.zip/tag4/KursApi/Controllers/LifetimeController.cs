using KursApi.Services;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class LifetimeController : ControllerBase
{
    private readonly IGreetingService _a;
    private readonly IGreetingService _b;

    public LifetimeController(IGreetingService a, IGreetingService b)
    {
        _a = a;
        _b = b;
    }

    [HttpGet]
    public object Get() => new
    {
        A = _a.InstanceId,
        B = _b.InstanceId,
        Text = _a.Greet("Kurs")
    };
}
