using KursApi.Data;
using KursApi.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class BooksController : ControllerBase
{
    private readonly LibraryContext _db;
    private readonly ILogger<BooksController> _logger;

    public BooksController(LibraryContext db, ILogger<BooksController> logger)
    {
        _db = db;
        _logger = logger;
    }

    [HttpGet]
    public async Task<ActionResult<IEnumerable<Book>>> GetAll()
        => Ok(await _db.Books.ToListAsync());

    [HttpGet("{id:int}")]
    public async Task<ActionResult<Book>> Get(int id)
    {
        var book = await _db.Books.FindAsync(id);
        if (book is null)
        {
            _logger.LogWarning("Buch {BookId} nicht gefunden", id);
            return NotFound();
        }
        return book;
    }

    [HttpPost]
    public async Task<ActionResult<Book>> Create(Book book)
    {
        _db.Books.Add(book);
        await _db.SaveChangesAsync();
        _logger.LogInformation("Buch {BookId} angelegt: {Title}", book.Id, book.Title);
        return CreatedAtAction(nameof(Get), new { id = book.Id }, book);
    }

    [HttpPut("{id:int}")]
    public async Task<IActionResult> Update(int id, Book input)
    {
        var book = await _db.Books.FindAsync(id);
        if (book is null) return NotFound();
        book.Title = input.Title;
        book.Author = input.Author;
        book.Year = input.Year;
        await _db.SaveChangesAsync();
        return NoContent();
    }

    [HttpDelete("{id:int}")]
    public async Task<IActionResult> Delete(int id)
    {
        var book = await _db.Books.FindAsync(id);
        if (book is null) return NotFound();
        _db.Books.Remove(book);
        await _db.SaveChangesAsync();
        _logger.LogInformation("Buch {BookId} gelöscht", id);
        return NoContent();
    }

    [HttpPost("{id:int}/reviews")]
    public async Task<IActionResult> AddReview(int id, ReviewDto input)
    {
        if (!await _db.Books.AnyAsync(b => b.Id == id)) return NotFound();

        var review = new Review { BookId = id, Stars = input.Stars, Comment = input.Comment };
        _db.Reviews.Add(review);
        await _db.SaveChangesAsync();
        return CreatedAtAction(nameof(GetDetails), new { id }, new { review.Id, review.Stars, review.Comment });
    }

    [HttpGet("{id:int}/details")]
    public async Task<IActionResult> GetDetails(int id)
    {
        var book = await _db.Books
            .Where(b => b.Id == id)
            .Select(b => new
            {
                b.Id,
                b.Title,
                b.Author,
                AverageStars = b.Reviews.Average(r => (double?)r.Stars),
                Reviews = b.Reviews.Select(r => new { r.Id, r.Stars, r.Comment }).ToList()
            })
            .FirstOrDefaultAsync();
        if (book is null) return NotFound();
        return Ok(book);
    }

    [HttpGet("ratings")]
    public async Task<IActionResult> GetRatings()
        => Ok(await _db.Books
            .Select(b => new
            {
                b.Title,
                ReviewCount = b.Reviews.Count,
                AverageStars = b.Reviews.Average(r => (double?)r.Stars)
            })
            .OrderByDescending(x => x.AverageStars)
            .ToListAsync());
}
