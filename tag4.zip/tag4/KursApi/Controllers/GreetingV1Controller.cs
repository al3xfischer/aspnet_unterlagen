using Asp.Versioning;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[ApiVersion("1.0")]
[Route("api/v{version:apiVersion}/greeting")]
public class GreetingV1Controller : ControllerBase
{
    [HttpGet]
    public string Get() => "Hallo aus Version 1";
}
