using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class CalcController : ControllerBase
{
    [HttpGet("add")]
    public int Add([FromQuery] int a, [FromQuery] int b) => a + b;

    [HttpGet("divide")]
    public ActionResult<double> Divide(int a, int b)
    {
        if (b == 0)
            return BadRequest("Division durch 0 ist nicht erlaubt.");
        return (double)a / b;
    }

    [HttpPost("sum")]
    public int Sum([FromBody] int[] numbers) => numbers.Sum();
}
