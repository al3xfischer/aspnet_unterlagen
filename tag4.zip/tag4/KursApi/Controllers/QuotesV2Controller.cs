using Asp.Versioning;
using KursApi.Models;
using KursApi.Services;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;

namespace KursApi.Controllers;

[ApiController]
[ApiVersion("2.0")]
[Route("api/v{version:apiVersion}/quotes")]
[Authorize]
public class QuotesV2Controller : ControllerBase
{
    private readonly IQuoteService _service;
    private readonly IOutputCacheStore _cache;

    public QuotesV2Controller(IQuoteService service, IOutputCacheStore cache)
    {
        _service = service;
        _cache = cache;
    }

    [HttpGet, AllowAnonymous, OutputCache(Duration = 60, Tags = new[] { "quotes" })]
    public async Task<ActionResult<IEnumerable<Quote>>> GetAll()
        => Ok(await _service.GetAllAsync());

    [HttpGet("{id:int}"), AllowAnonymous]
    public async Task<ActionResult<Quote>> GetById(int id)
    {
        var quote = await _service.GetAsync(id);
        if (quote is null) return NotFound();
        return quote;
    }

    [HttpPost]
    public async Task<ActionResult<Quote>> Create(Quote quote, CancellationToken ct)
    {
        var created = await _service.AddAsync(quote);
        if (created is null) return Conflict("Maximale Anzahl Zitate erreicht.");
        await _cache.EvictByTagAsync("quotes", ct);
        return CreatedAtAction(nameof(GetById),
            new { id = created.Id, version = "2.0" }, created);
    }

    [HttpDelete("{id:int}"), Authorize(Policy = "AdminOnly")]
    public async Task<IActionResult> Delete(int id, CancellationToken ct)
    {
        if (!await _service.DeleteAsync(id)) return NotFound();
        await _cache.EvictByTagAsync("quotes", ct);
        return NoContent();
    }
}
