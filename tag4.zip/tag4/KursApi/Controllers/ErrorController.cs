using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class ErrorController : ControllerBase
{
    [HttpGet("boom")]
    public IActionResult Boom() => throw new InvalidOperationException("Absichtlicher Fehler");

    [HttpGet("missing")]
    public IActionResult Missing() => throw new KeyNotFoundException();
}
