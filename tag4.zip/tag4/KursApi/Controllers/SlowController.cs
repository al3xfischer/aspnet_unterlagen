using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.OutputCaching;
using Microsoft.Extensions.Caching.Memory;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class SlowController : ControllerBase
{
    [HttpGet, OutputCache(Duration = 30, Tags = new[] { "slow" })]
    public async Task<string> Get()
    {
        await Task.Delay(3000);
        return $"Berechnet um {DateTime.Now:T}";
    }

    [HttpGet("memory")]
    public async Task<string?> GetMemory([FromServices] IMemoryCache cache)
    {
        return await cache.GetOrCreateAsync("slow-value", async entry =>
        {
            entry.AbsoluteExpirationRelativeToNow = TimeSpan.FromSeconds(30);
            await Task.Delay(3000);
            return $"Berechnet um {DateTime.Now:T}";
        });
    }

    [HttpPost("clear")]
    public async Task<IActionResult> Clear([FromServices] IOutputCacheStore store, CancellationToken ct)
    {
        await store.EvictByTagAsync("slow", ct);
        return NoContent();
    }
}
