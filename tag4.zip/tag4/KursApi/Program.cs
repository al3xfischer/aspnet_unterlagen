using Asp.Versioning;
using KursApi.Configuration;
using KursApi.Data;
using KursApi.Infrastructure;
using KursApi.Services;
using Microsoft.AspNetCore.RateLimiting;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Diagnostics.HealthChecks;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddControllers()
    .AddXmlSerializerFormatters()
    .AddJsonOptions(o => o.JsonSerializerOptions.WriteIndented = true);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen(o =>
{
    o.SwaggerDoc("v1", new() { Title = "KursApi", Version = "v1" });
    o.SwaggerDoc("v2", new() { Title = "KursApi", Version = "v2" });
    var xml = Path.Combine(AppContext.BaseDirectory, "KursApi.xml");
    o.IncludeXmlComments(xml);
});

builder.Services.AddApiVersioning(o =>
{
    o.DefaultApiVersion = new ApiVersion(1, 0);
    o.AssumeDefaultVersionWhenUnspecified = true;
    o.ReportApiVersions = true;
})
.AddMvc()
.AddApiExplorer(o =>
{
    o.GroupNameFormat = "'v'VVV";
    o.SubstituteApiVersionInUrl = true;
});

builder.Services.Configure<GreetingOptions>(builder.Configuration.GetSection("Greeting"));
builder.Services.Configure<QuoteOptions>(builder.Configuration.GetSection("Quotes"));

builder.Services.AddDbContext<LibraryContext>(o =>
    o.UseSqlite(builder.Configuration.GetConnectionString("Library")));

builder.Services.AddTransient<IGreetingService, GreetingService>();
builder.Services.AddScoped<IQuoteService, QuoteService>();

builder.Services.AddProblemDetails();
builder.Services.AddExceptionHandler<GlobalExceptionHandler>();

builder.Services.AddAuthentication().AddJwtBearer();
builder.Services.AddAuthorization(o =>
    o.AddPolicy("AdminOnly", p => p.RequireRole("Admin")));
builder.Services.AddRateLimiter(o =>
{
    o.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
    o.AddFixedWindowLimiter("fixed", l =>
    {
        l.PermitLimit = 5;
        l.Window = TimeSpan.FromSeconds(10);
    });
});

builder.Services.AddOutputCache();
builder.Services.AddMemoryCache();

builder.Services.AddHealthChecks()
    .AddDbContextCheck<LibraryContext>()
    .AddCheck("api", () => HealthCheckResult.Healthy("API läuft"));

var app = builder.Build();

app.UseExceptionHandler();

if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI(o =>
    {
        o.SwaggerEndpoint("/swagger/v1/swagger.json", "v1");
        o.SwaggerEndpoint("/swagger/v2/swagger.json", "v2");
    });
}

app.UseHttpsRedirection();
app.UseAuthentication();
app.UseAuthorization();
app.UseRateLimiter();
app.UseOutputCache();

app.MapControllers();
app.MapHealthChecks("/health");

app.Run();
