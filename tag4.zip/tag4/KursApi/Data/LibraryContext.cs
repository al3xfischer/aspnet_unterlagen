using KursApi.Models;
using Microsoft.EntityFrameworkCore;

namespace KursApi.Data;

public class LibraryContext : DbContext
{
    public LibraryContext(DbContextOptions<LibraryContext> options) : base(options) { }

    public DbSet<Book> Books => Set<Book>();
    public DbSet<Review> Reviews => Set<Review>();
    public DbSet<Quote> Quotes => Set<Quote>();
}
