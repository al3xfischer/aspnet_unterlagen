using System.ComponentModel.DataAnnotations;

namespace KursApi.Models;

public class ReviewDto
{
    [Range(1, 5)]
    public int Stars { get; set; }
    public string Comment { get; set; } = "";
}
