using System.ComponentModel.DataAnnotations;

namespace KursApi.Models;

public class Quote
{
    public int Id { get; set; }

    [Required, StringLength(200)]
    public string Text { get; set; } = "";

    [StringLength(100)]
    public string? Author { get; set; }
}
