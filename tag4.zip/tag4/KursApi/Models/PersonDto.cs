using System.ComponentModel.DataAnnotations;

namespace KursApi.Models;

public class PersonDto
{
    [Required(ErrorMessage = "Bitte einen Namen angeben.")]
    [StringLength(50, MinimumLength = 2,
        ErrorMessage = "Der Name muss zwischen 2 und 50 Zeichen lang sein.")]
    public string Name { get; set; } = "";

    [Range(0, 130, ErrorMessage = "Das Alter muss zwischen 0 und 130 liegen.")]
    public int Age { get; set; }

    [EmailAddress(ErrorMessage = "Bitte eine gültige E-Mail-Adresse angeben.")]
    public string? Email { get; set; }
}
