namespace KursApi.Configuration;

public class QuoteOptions
{
    public int MaxQuotes { get; set; } = 10;
}
