namespace KursApi.Configuration;

public class GreetingOptions
{
    public string Text { get; set; } = "";
    public int Repeat { get; set; } = 1;
}
