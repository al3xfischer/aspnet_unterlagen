using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class HelloController : ControllerBase
{
    [HttpGet]
    public string Get() => "Hallo Welt";

    /// <summary>Begrüßt eine Person mit Namen.</summary>
    /// <param name="name">Name der Person</param>
    /// <returns>Die Begrüßung</returns>
    /// <response code="200">Begrüßung erfolgreich</response>
    [HttpGet("{name}")]
    public string Get(string name) => $"Hallo {name}";

    [HttpGet("{name}/{times:int}")]
    public string Get(string name, int times)
        => string.Join(" ", Enumerable.Repeat($"Hallo {name}", times));
}
