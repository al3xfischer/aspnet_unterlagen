using KursApi.Models;
using Microsoft.AspNetCore.Mvc;

namespace KursApi.Controllers;

[ApiController]
[Route("api/[controller]")]
public class QuotesController : ControllerBase
{
    private static readonly List<Quote> _quotes = new()
    {
        new Quote { Id = 1, Text = "Erst denken, dann coden." },
        new Quote { Id = 2, Text = "Auf meinem Rechner läuft es." }
    };

    /// <summary>Liefert alle Zitate.</summary>
    [HttpGet]
    public ActionResult<IEnumerable<Quote>> GetAll() => Ok(_quotes);

    /// <summary>Liefert ein Zitat.</summary>
    /// <response code="404">Zitat nicht gefunden</response>
    [HttpGet("{id:int}")]
    public ActionResult<Quote> GetById(int id)
    {
        var quote = _quotes.FirstOrDefault(q => q.Id == id);
        if (quote is null) return NotFound();
        return quote;
    }

    /// <summary>Liefert ein zufälliges Zitat.</summary>
    [HttpGet("random")]
    public ActionResult<Quote> GetRandom()
    {
        if (_quotes.Count == 0) return NotFound();
        return _quotes[Random.Shared.Next(_quotes.Count)];
    }

    /// <summary>Legt ein Zitat an.</summary>
    /// <response code="201">Zitat angelegt</response>
    [HttpPost]
    public ActionResult<Quote> Create(Quote quote)
    {
        quote.Id = _quotes.Count == 0 ? 1 : _quotes.Max(q => q.Id) + 1;
        _quotes.Add(quote);
        return CreatedAtAction(nameof(GetById), new { id = quote.Id }, quote);
    }

    /// <summary>Ersetzt den Text eines Zitats.</summary>
    [HttpPut("{id:int}")]
    public IActionResult Update(int id, Quote input)
    {
        var quote = _quotes.FirstOrDefault(q => q.Id == id);
        if (quote is null) return NotFound();
        quote.Text = input.Text;
        return NoContent();
    }

    /// <summary>Löscht ein Zitat.</summary>
    [HttpDelete("{id:int}")]
    public IActionResult Delete(int id)
    {
        var quote = _quotes.FirstOrDefault(q => q.Id == id);
        if (quote is null) return NotFound();
        _quotes.Remove(quote);
        return NoContent();
    }
}
